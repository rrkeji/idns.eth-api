$(function () {
    $('#root2').html("<h1>in test.js</h1>");
});